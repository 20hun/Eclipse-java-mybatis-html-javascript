
public class SchoolManager {
	Human[] arr = new Human[100];
	int count = 0;
	
	public boolean insertHuman (Human a) {
		for(int i = 0 ; i<count ; i++) {
			if(a.getSn().equals(arr[i].getSn())) { 
				return false;
			}
			}
			if(a instanceof Student) {
				Student s = (Student) a;
				Student[] arr2 = new Student[100];
				for(int j = 0; j<count;j++) {
					arr2[j] = (Student) arr[j];
					if(s.getSsn().equals(arr2[j].getSsn())){
						return false;
					}
				}
			}
		arr[count] = a;
		count++;
		//�迭�� ��ü �ϳ��� �ִ� �޼ҵ� ������ count++�� ����
		//�޼ҵ� ���� �� arr[count]�� null ����
		return true;
		}

	public Human findHuman (String a) {
		for(int i = 0 ; i<count ; i++) {
		if(a.equals(arr[i].getSn())) {
			return arr[i];
		}
		}
		return null;
	}
	
	public boolean deleteHuman (Human a) {
		for(int i = 0 ; i<count ; i++) {
			if(a.equals(arr[i])) {
				arr[i] = null;
				for(int j = i ; j<count ; j++) {
				arr[i] = arr[i+1];
				}
				count--;
				return true;
			}
		}
		return false;
	}
	
	public void printAll() {
		for(int i = 0 ; i<count ; i++) {
			arr[i].print();
		}
	}

}